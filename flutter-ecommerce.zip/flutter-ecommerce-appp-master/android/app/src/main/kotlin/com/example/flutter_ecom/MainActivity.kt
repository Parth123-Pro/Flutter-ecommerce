package com.example.flutter_ecom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
